package academy.variables;

public class MyFirstVariables {
    public static void main(String[] args) {
        float floatNumber = 10.5f;
        System.out.println(floatNumber);
        int currentYear =2022;
        System.out.println(currentYear);
        double doubleNumber = -13.4;
        System.out.println(doubleNumber);
        byte byteNumber = 110;
        System.out.println(byteNumber);
        char myFavouriteCaracter = 'm';
        System.out.println(myFavouriteCaracter);

        String firstName = "Mateja";
        System.out.println(firstName);
        String lastName = "Stojkovski";
        System.out.println(lastName);
        System.out.println( firstName + lastName);
        int textLenght = lastName.length();
        System.out.println(textLenght);
        String newLastname = lastName.toUpperCase();
        System.out.println(newLastname);

        int firstNumber = 20;
        int secondNumber = 6;
        int result = firstNumber * secondNumber;
        System.out.println(result);
        int divide = firstNumber / secondNumber;
        System.out.println(divide);
        int mod = firstNumber % secondNumber;
        System.out.println(mod);
        int subtract = firstNumber - secondNumber;
        System.out.println(subtract);
        int sum = firstNumber + secondNumber;
        System.out.println(sum);

    }

}