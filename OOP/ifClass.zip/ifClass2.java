public class ifClass2 {
    public static void main(String[] args) {

        for (int i = 1000; i >= 100; i--) {
            int number = i % 2;
            if (number == 0) {
                System.out.println(i);
            }
        }
    }
}
