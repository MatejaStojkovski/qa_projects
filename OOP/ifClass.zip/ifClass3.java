public class ifClass3 {
    public static void main(String[] args) {

        for (int i = 100; i <= 1000; i++) {
            int num = i % 2;
            if (num == 1) {
                System.out.println(i);
            }
        }
    }
}
