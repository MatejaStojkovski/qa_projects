import java.util.Scanner;

public class ifClass {
    public static void main(String[] args) {

        Scanner accessories = new Scanner(System.in);

        System.out.println("Enter value below:");
        int pencil = accessories.nextInt();
        System.out.println("Value is: " + pencil);

        System.out.println("Enter another value below:");
        int pen = accessories.nextInt();
        System.out.println("Value is: " + pen);

        if (pencil < pen) {
            System.out.println("pencil is less than pen: true");
        } else {
            System.out.println("pencil is less than pen: false");
        }

        if (pencil > pen) {
            System.out.println("pencil is greater than pen: true");
        } else {
            System.out.println("pencil is greater than pen: false");
        }

        if (pencil == pen) {
            System.out.println("pencil is equal to pen: true");
        } else {
            System.out.println("pencil is equal to pen: false");
        }

        if (pencil + pen < 46) {
            System.out.println("the sum of pencil and pen is less than 46: true");
        } else {
            System.out.println("the sum of pencil and pen is less than 46: false");
        }

        if (pencil - pen > 13) {
            System.out.println("the difference of pencil and pen is greater than 13: true");
        } else {
            System.out.println("the difference of pencil and pen is greater than 13: false");
        }

        if (pencil / pen >= 9) {
            System.out.println("the quotient of pencil and pen is greater than or equal to 9: true");
        } else {
            System.out.println("the quotient of pencil and pen is greater than or equal to 9: false");
        }

        if (pencil * pen > 250) {
            System.out.println("the product of pencil and pen is greater than 250: true");
        } else {
            System.out.println("the product of pencil and pen is greater than 250: false");
        }


    }
}
