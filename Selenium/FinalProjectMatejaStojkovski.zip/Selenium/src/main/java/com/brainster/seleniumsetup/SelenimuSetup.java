package com.brainster.seleniumsetup;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;
public class SelenimuSetup {
    private static WebDriver driver;
    private static String email;
    private static String password;
    private static String emailForTransporter;
    private static String passwordForTransporter;
    public static void setup() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }
    public static void clickOn(String elementXpath) {
        WebElement tempElement = driver.findElement(By.xpath(elementXpath));
        tempElement.click();
    }
    public static void typeIn(String elementXpath, String text) {
        driver.findElement(By.xpath(elementXpath)).sendKeys(text);
    }
    public static void selectItemByVisibleText(String elementXpath, String visibleText) {
        Select typeOfUserDdl = new Select(driver.findElement(By.xpath(elementXpath)));
        typeOfUserDdl.selectByVisibleText(visibleText);
    }
    public static String getText(String elementXpath) {
        return driver.findElement(By.xpath(elementXpath)).getText();
    }
    public static void waitFor(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    public static String navigationTo() {
        driver.get("http://18.156.17.83:9095/");
        return driver.getCurrentUrl();
    }
    public static String RegistrationAsClient() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        waitFor(2);
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanov");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div");
    }
    public static String logMeIn() {
        clickOn("//*[@id=\"login\"]");
        typeIn("//*[@id=\"username\"]", email);
        typeIn("//*[@id=\"password\"]", password);
        clickOn("/html/body/div[1]/div/div/div[2]/div/div[2]/form/button");
        return getText("/html/body/div[1]/div/div/div[2]/div/div[1]/div");
    }
    public static String contact() {
        clickOn("/html/body/div[3]/div[2]/div[1]/ul/li[3]/a");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[3]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[4]/div[2]/input", email);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[5]/div[2]/input", "subject");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[6]/div[2]/textarea", "Massage is about");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[7]/button");
        return getText("/html/body/div[3]/div[1]/div/div/div/div[1]/div/div[1]/strong");
    }

    public static String EditProfile() {
        clickOn("/html/body/div[1]/nav/div[1]");
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[2]/a/span[2]");
        typeIn("/html/body/div[3]/div[1]/div[2]/div/div[3]/div/form/div[4]/div/input", "0");
        typeIn("/html/body/div[3]/div[1]/div[2]/div/div[3]/div/form/div[5]/div/input", "o");
        clickOn("/html/body/div[3]/div[1]/div[2]/div/div[3]/div/form/div[11]/div/div/button[1]");
        return getText("/html/body/div[3]/div[1]/div[2]/div/div[1]/strong");
    }
    public static String support() {
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[6]/a");
        typeIn("/html/body/div[3]/div[1]/div[2]/div/div/div/div[3]/div[1]/input", "Question subject");
        typeIn("/html/body/div[3]/div[1]/div[2]/div/div/div/div[3]/div[2]/textarea", "Question ????????");
        clickOn("/html/body/div[3]/div[1]/div[2]/div/div/div/div[3]/button");
        return getText("/html/body/div[3]/div[1]/div[2]/div/div/div/div[1]/strong");
    }
    public static String createRequest() {
        clickOn("/html/body/div[1]/nav/div[1]");
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[3]/a");
        typeIn("//*[@id=\"newRequestForm\"]/div/div[2]/div[2]/input", "Books");
        typeIn("//*[@id=\"field_y\"]", "Комбе" + Keys.ENTER);
        WebElement pickUpTxt = driver.findElement(By.xpath("//*[@id=\"newRequestForm\"]/div/div[4]/div[2]/place-search-field/input"));
        pickUpTxt.sendKeys("Madrid, Spain");
        waitFor(2);
        pickUpTxt.sendKeys(Keys.ARROW_DOWN);
        pickUpTxt.sendKeys(Keys.ENTER);
        WebElement deliveryTxt = driver.findElement(By.xpath("//*[@id=\"newRequestForm\"]/div/div[5]/div[2]/place-search-field/input"));
        deliveryTxt.sendKeys("Veles, North Macedonia");
        waitFor(2);
        deliveryTxt.sendKeys(Keys.ARROW_DOWN);
        deliveryTxt.sendKeys(Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[1]/div[2]/input", "3" + Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[2]/div[2]/input", "3" + Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[3]/div[2]/textarea", "3 Books");
        clickOn("//*[@id=\"combeTypeNormal\"]");
        clickOn("//*[@id=\"cacheDelivery\"]");
        clickOn("//*[@id=\"newRequestForm\"]/div/div[14]/input");
        return getText("/html/body/div[3]/div[1]/div[2]/div/request-list-pagination/jhi-alert/div/div/div/div/pre");
    }
    public static String createRequest2() {
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[3]/a");
        typeIn("//*[@id=\"newRequestForm\"]/div/div[2]/div[2]/input", "Milk");
        typeIn("//*[@id=\"field_y\"]", "Комбе" + Keys.ENTER);
        WebElement pickUpTxt = driver.findElement(By.xpath("//*[@id=\"newRequestForm\"]/div/div[4]/div[2]/place-search-field/input"));
        pickUpTxt.sendKeys("Serbia");
        waitFor(2);
        pickUpTxt.sendKeys(Keys.ARROW_DOWN);
        pickUpTxt.sendKeys(Keys.ENTER);
        WebElement deliveryTxt = driver.findElement(By.xpath("//*[@id=\"newRequestForm\"]/div/div[5]/div[2]/place-search-field/input"));
        deliveryTxt.sendKeys("Skopje, Северна Македонија");
        waitFor(2);
        deliveryTxt.sendKeys(Keys.ARROW_DOWN);
        deliveryTxt.sendKeys(Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[1]/div[2]/input", "10" + Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[2]/div[2]/input", "10" + Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[3]/div[2]/textarea", "10kg Milk ");
        clickOn("//*[@id=\"combeTypeRefrigerator\"]");
        clickOn("//*[@id=\"advance\"]");
        clickOn("//*[@id=\"newRequestForm\"]/div/div[14]/input");
        return getText("/html/body/div[3]/div[1]/div[2]/div/request-list-pagination/jhi-alert/div/div/div/div/pre");
    }
    public static String createRequest3() {
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[3]/a");
        typeIn("//*[@id=\"newRequestForm\"]/div/div[2]/div[2]/input", "Chocolate");
        typeIn("//*[@id=\"field_y\"]", "Комбе" + Keys.ENTER);
        WebElement pickUpTxt = driver.findElement(By.xpath("//*[@id=\"newRequestForm\"]/div/div[4]/div[2]/place-search-field/input"));
        pickUpTxt.sendKeys("Germany");
        waitFor(2);
        pickUpTxt.sendKeys(Keys.ARROW_DOWN);
        pickUpTxt.sendKeys(Keys.ENTER);
        WebElement deliveryTxt = driver.findElement(By.xpath("//*[@id=\"newRequestForm\"]/div/div[5]/div[2]/place-search-field/input"));
        deliveryTxt.sendKeys("Kumanovo, Северна Македонија");
        waitFor(2);
        deliveryTxt.sendKeys(Keys.ARROW_DOWN);
        deliveryTxt.sendKeys(Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[1]/div[2]/input", "100" + Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[2]/div[2]/input", "100" + Keys.ENTER);
        typeIn("//*[@id=\"newRequestForm\"]/div/div[10]/div[3]/div[2]/textarea", "100 boxes Chocolate ");
        clickOn("//*[@id=\"combeTypeNormal\"]");
        clickOn("//*[@id=\"cachePickup\"]");
        clickOn("//*[@id=\"newRequestForm\"]/div/div[14]/input");
        return getText("/html/body/div[3]/div[1]/div[2]/div/request-list-pagination/jhi-alert/div/div/div/div/pre");
    }
    public static String logout() {
        clickOn("//*[@id=\"logout2\"]/span");
        driver.get("http://18.156.17.83:9095/");
        return driver.getCurrentUrl();
    }
    public static String RegisterAsTransporter() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "BucenKozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        waitFor(2);
        return getText("/html/body/div[3]/div[1]/div/div/h3");
    }
    public static String logMeInAsTransporter() {
        clickOn("//*[@id=\"login\"]");
        typeIn("//*[@id=\"username\"]", emailForTransporter);
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        clickOn("/html/body/div[1]/div/div/div[2]/div/div[2]/form/button");
        return getText("/html/body/div[3]/div[1]/div[2]/request-search-list/jhi-alert/div");
    }
    public static String SearchRequest() {
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[1]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[1]/country-selector/div/input[1]", "Germany" + Keys.ENTER);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[3]/a/span[2]");
        return getText("/html/body/div[3]/div[1]/div[2]/request-search-list/div[2]/request-list/div[2]/div[1]/table/thead/tr/th[1]/span");
    }
    public static String SelectRequest() {
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[2]/request-list/div[2]/div[2]/table/tbody/tr[1]/td[1]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[5]/div/div[2]/div/button");
        typeIn("/html/body/div[3]/div[1]/div[2]/form/div/div[4]/div/div[1]/div[3]/input", "23.11.2022 13:00");
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div[2]/form/div/div[2]/div[2]/table/tbody/tr/td[5]/input", "10");
        clickOn("/html/body/div[3]/div[1]/div[2]/form/div/div[5]/button");
        clickOn("/html/body/div[1]/div/div/div[3]/button[1]");
        return getText("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[1]/div/h2");
    }
    public static String SearchRequest2() {
        clickOn("/html/body/div[1]/nav/div[1]/a/img");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[1]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[1]/country-selector/div/input[1]", "Serbia" + Keys.ENTER);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[3]/a/span[2]");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div[2]/request-search-list/div[2]/request-list/div[2]/div[1]/table/thead/tr/th[1]/span");
    }
    public static String SelectRequest2() {
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[2]/request-list/div[2]/div[2]/table/tbody/tr[1]/td[1]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[5]/div/div[2]/div/button");
        typeIn("/html/body/div[3]/div[1]/div[2]/form/div/div[4]/div/div[1]/div[3]/input", "24.11.2022 14:00");
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div[2]/form/div/div[2]/div[2]/table/tbody/tr/td[5]/input", "120");
        clickOn("/html/body/div[3]/div[1]/div[2]/form/div/div[5]/button");
        clickOn("/html/body/div[1]/div/div/div[3]/button[1]");
        return getText("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[1]/div/h2");
    }
    public static String SearchRequest3() {
        clickOn("/html/body/div[1]/nav/div[1]/a/img");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[1]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[1]/country-selector/div/input[1]", "Spain" + Keys.ENTER);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[2]/div[1]/div/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[1]/div[2]/request-search/div/div/div[3]/a/span[2]");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div[2]/request-search-list/div[2]/request-list/div[2]/div[1]/table/thead/tr/th[1]/span");
    }
    public static String SelectRequest3() {
        clickOn("/html/body/div[3]/div[1]/div[2]/request-search-list/div[2]/request-list/div[2]/div[2]/table/tbody/tr[1]/td[1]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[5]/div/div[2]/div/button");
        typeIn("/html/body/div[3]/div[1]/div[2]/form/div/div[4]/div/div[1]/div[3]/input", "24.11.2022 14:00");
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div[2]/form/div/div[2]/div[2]/table/tbody/tr/td[5]/input", "120");
        clickOn("/html/body/div[3]/div[1]/div[2]/form/div/div[5]/button");
        clickOn("/html/body/div[1]/div/div/div[3]/button[1]");
        return getText("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[1]/div/h2");
    }
    public static String DenyOffer() {
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[4]/a/span[2]");
        clickOn("/html/body/div[3]/div[1]/div[2]/div/request-list-pagination/request-list/div[2]/div[2]/table/tbody/tr[1]/td[1]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[8]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[2]/button");
        return getText("/html/body/div[3]/div[1]/div[2]/ul/li[2]/a/span[2]");
    }
    public static String AcceptOffer() {
        clickOn("/html/body/div[1]/nav/div[1]/a/img");
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[4]/a/span[2]");
        clickOn("/html/body/div[3]/div[1]/div[2]/div/request-list-pagination/request-list/div[2]/div[2]/table/tbody/tr[1]/td[1]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[8]/a");
        clickOn("//*[@id=\"offer0\"]");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[10]/div/div/div/div[1]/div[2]/div[6]/input");
        return getText("/html/body/div[3]/div[1]/div[2]/ul/li[2]/a/span[2]");
    }
    public static String AcceptOffer2() {
        clickOn("/html/body/div[1]/nav/div[1]/a/img");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div[1]/ul/li[4]/a/span[2]");
        clickOn("/html/body/div[3]/div[1]/div[2]/div/request-list-pagination/request-list/div[2]/div[2]/table/tbody/tr[1]/td[1]/a");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[8]/a");
        clickOn("//*[@id=\"offer0\"]");
        clickOn("/html/body/div[3]/div[1]/div[2]/div[1]/div[6]/div[2]/div/div/div[2]/div/div[10]/div/div/div/div[1]/div[2]/div[6]/input");
        return getText("/html/body/div[3]/div[1]/div[2]/ul/li[2]/a/span[2]");
    }
    public static String RegistrationAsClientOnlyWithFirstName() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithLessThanThreeCharactersInFirstName() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Ma");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithEmptyLastName() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithLessThaThreeCharacterInAddress() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithLessThanThreeSpecialCharacters() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "--");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithSpecialCharacter$InPostalCode() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithLettersOnPhoneNumberField() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "dalimozedasenajavambezbrojki");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithoutEmail() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithoutPrefixInEmail() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        typeIn("//*[@id=\"email\"]", "@gmail.com");
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithoutDomainInEmail() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        typeIn("//*[@id=\"email\"]", "@gmail.com");
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithoutPassword() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }
    public static String RegistrationAsClientWithWrongConfirmPassword() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", "1234567");
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[1]/div[5]");
    }
    public static String RegistrationAsClientAcceptTerms() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        waitFor(1);
        clickOn("/html/body/div[3]/div[1]/div/div/div[1]/button");
        selectItemByVisibleText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[1]/div[2]/select", "Физичко лице");
        typeIn("//*[@id=\"firstName\"]", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[4]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[1]/div[2]/input", "Dr.Ribar 2");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[3]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[5]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[7]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        waitFor(1);
        typeIn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[6]/div[9]/div[2]/input", "078377954");
        email = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("//*[@id=\"email\"]", email);
        password = "123456";
        typeIn("//*[@id=\"password\"]", password);
        typeIn("//*[@id=\"confirmPassword\"]", password);
        clickOn("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/input");
        waitFor(1);
        return getText("/html/body/div[3]/div[1]/div/div/div/div[2]/form/div[15]/div/p");
    }

    public static String RegisterAsTransporterWithLessThanThreeCharactersInFirstName() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Ma");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithEmptyLastName() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", " ");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithOneCharacterCompany() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "B");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithMoreThanHundredCharactersInAddress() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "D$$1294808^^^7&&&8*(()839201847912hjikdwhqkdlhnhdjqw789421784971491*/-/*-/*-/-/*-/*-/fregrgvbfdsfvreqgfreqwnajioepn2y89");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithEmptyCity() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithLessThanThreeCharactersInPostalCode() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "13");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithLessThanFiveCharactersInTaxNumber() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "1234");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithMoreThanTwentyCharactersInPhoneNumber() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "123456789745364878974");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithInvalidEmail() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", "email@gmail.com");
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithoutPrefixInEmail() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", "@gmail.com");
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithoutDomainInEmail() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", "matejakrstevska98@");
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithEmptyPassword() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithWrongConfirmPassword() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", "Hello");
        clickOn("//*[@id=\"acceptTerms\"]");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static String RegisterAsTransporterWithoutSelectAcceptTerms() {
        clickOn("/html/body/div[1]/nav/div[3]/ul/li[3]/a");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/button");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[1]/div[2]/input", "Mateja");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[3]/div[2]/input", "Stojkovski");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[5]/div[2]/input", "Bucen Kozjak");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[7]/div[2]/input", "Kozjacka 11");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[9]/div[2]/input", "Kumanovo");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[11]/div[2]/input", "1300");
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/div[1]/span");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[13]/div[2]/country-selector/div/input[1]", "Macedonia" + Keys.ENTER);
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[15]/div[2]/input", "123456");
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[1]/div[16]/div[2]/input", "078377954");
        emailForTransporter = "MS" + System.currentTimeMillis() + "@gmail.com";
        typeIn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[2]/div[2]/input", emailForTransporter);
        passwordForTransporter = "123456";
        typeIn("//*[@id=\"password\"]", passwordForTransporter);
        typeIn("//*[@id=\"confirmPassword\"]", passwordForTransporter);
        clickOn("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/input");
        return getText("/html/body/div[3]/div[1]/div/div/div[2]/form/div[10]/div/p");
    }
    public static void end() {
        driver.quit();
    }
}
