import com.brainster.seleniumsetup.SelenimuSetup;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class SeleniumTests {
    @BeforeClass
    public void beforeClass() {
        SelenimuSetup.setup();
    }
    @Test(priority = 10)
    public void testForVerifyUserReachedHomePage() {
        Assert.assertEquals(SelenimuSetup.navigationTo(), "http://18.156.17.83:9095/");
    }
    @Test(priority = 11)
    public void TestForVerifyUserCanNotBeRegisterAsClientOnlyWithFirstName() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientOnlyWithFirstName(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 12)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithLessThanThreeCharactersInFirstName() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithLessThanThreeCharactersInFirstName(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 13)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithThirtyCharactersInLastName() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithEmptyLastName(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 14)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithInvalidSpecialCharacterInAddress() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithLessThaThreeCharacterInAddress(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 15)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithLessThanThreeSpecialCharacters() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithLessThanThreeSpecialCharacters(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 16)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithFiftyCharactersInPostalCode() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithSpecialCharacter$InPostalCode(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 17)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithLettersOnPhoneNumberField() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithLettersOnPhoneNumberField(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 18)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithoutEmail() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithoutEmail(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 19)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithoutPassword() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithoutPassword(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 20)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithWrongConfirmPassword() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithWrongConfirmPassword(), "Вашата лозинка не соодветсвува со потврдената лозинка!");
    }
    @Test(priority = 21)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithoutSelectAcceptTerms() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientAcceptTerms(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 22)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithoutPrefixInEmail() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithoutPrefixInEmail(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 23)
    public void TestForVerifyUserCanNotBeRegisterAsClientWithoutDomainInEmail() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClientWithoutDomainInEmail(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 24)
    public void TestForVerifyUserRegisteredAsClient() {
        Assert.assertEquals(SelenimuSetup.RegistrationAsClient(), "ДОБРЕДОЈДОВТЕ!\n" +
                "Вашиот профил е успешно креиран! Ве молиме проверете го Вашиот e-mail за да ја завршите регистрацијата.");
    }
    @Test(priority = 30)
    public void testForVerifyUserLoggedInAsClient() {
        Assert.assertEquals(SelenimuSetup.logMeIn(), "");
    }
    @Test(priority = 40)
    public void testForVerifyUserCanSentMassageToAdmin() {
        Assert.assertEquals(SelenimuSetup.support(), "");
    }
    @Test(priority = 45)
    public void testForVerifyUserCanEditProfile() {
        Assert.assertEquals(SelenimuSetup.EditProfile(), "");
    }
    @Test(priority = 50)
    public void testForVerifyRequest() {
        Assert.assertEquals(SelenimuSetup.createRequest(), "Успешно е креирано ново барање");
    }
    @Test(priority = 60)
    public void testForVerifyRequest1() {
        Assert.assertEquals(SelenimuSetup.createRequest2(), "Успешно е креирано ново барање");
    }
    @Test(priority = 70)
    public void testForVerifyRequest2() {
        Assert.assertEquals(SelenimuSetup.createRequest3(), "Успешно е креирано ново барање");
    }
    @Test(priority = 80)
    public void testForVerifyUserIsLoggedOut() {
        Assert.assertEquals(SelenimuSetup.logout(), "http://18.156.17.83:9095/");
    }
    @Test(priority = 81)
    public void testForVerifyUserCanNotBeRegisterAsTransporterWithLassThanThreeCharactersInFirstName() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithLessThanThreeCharactersInFirstName(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 82)
    public void testForVerifyUserCanNotBeRegisterAsTransporterWithEmptyLastName() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithEmptyLastName(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 83)
    public void testForVerifyUserCanNotBeRegisterAsTransporterWithOneCharacterInCompany() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithOneCharacterCompany(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 84)
    public void testForVerifyUserCanNotBeRegisterAsTransporterWithMoreThanHundredCharactersInAddress() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithMoreThanHundredCharactersInAddress(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 85)
    public void testForVerifyUserCanNotBeRegisterAsTransporterWithEmptyCity() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithEmptyCity(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 86)
    public void testForVerifyUserCanNotBeRegisterAsTransporterWithLassThanThreeCharactersInPostalCode() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithLessThanThreeCharactersInPostalCode(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 87)
    public void testForVerifyUserIsRegisteredAsTransporterWithLassThanFiveCharactersInTaxNumber() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithLessThanFiveCharactersInTaxNumber(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 88)
    public void testForVerifyUserIsRegisteredAsTransporterWithMoreThanTwentyCharactersInPhoneNumber() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithMoreThanTwentyCharactersInPhoneNumber(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 89)
    public void testForVerifyUserIsRegisteredAsTransporterWithInvalidEmail() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithInvalidEmail(), "");
    }
    @Test(priority = 90)
    public void testForVerifyUserIsRegisteredAsTransporterWithEmptyPassword() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithEmptyPassword(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 91)
    public void testForVerifyUserIsRegisteredAsTransporterWithWrongConfirmPassword() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithWrongConfirmPassword(), "");
    }
    @Test(priority = 92)
    public void testForVerifyUserIsRegisteredAsTransporterWithoutSelectAcceptTerms() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithoutSelectAcceptTerms(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 93)
    public void testForVerifyUserIsRegisteredAsTransporterWithoutPrefixInEmail() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithoutPrefixInEmail(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 94)
    public void testForVerifyUserIsRegisteredAsTransporterWithoutDomainInEmail() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporterWithoutDomainInEmail(), "Ве молиме пополнете ги сите задолжителни полиња!");
    }
    @Test(priority = 95)
    public void testForVerifyUserIsRegisteredAsTransporter() {
        Assert.assertEquals(SelenimuSetup.RegisterAsTransporter(), "Вашиот профил е успешно креиран! Ве молиме проверете го Вашиот e-mail за да ја завршите регистрацијата.");
    }
    @Test(priority = 100)
    public void testForVerifyUserIdLoggedInAsTransporter() {
        Assert.assertEquals(SelenimuSetup.logMeInAsTransporter(), "×\n" +
                "Close\n" +
                "providerPerson.created");
    }
    @Test(priority = 110)
    public void testForVerifyUserCanSearchTransport() {
        Assert.assertEquals(SelenimuSetup.SearchRequest(), "Наслов на барањето");
    }
    @Test(priority = 120)
    private void testForVerifyUserCanGivePrice() {
        Assert.assertEquals(SelenimuSetup.SelectRequest(), "Понуди за барањето");
    }
    @Test(priority = 130)
    public void testForVerifyUserCanSearchTransport2() {
        Assert.assertEquals(SelenimuSetup.SearchRequest2(), "Наслов на барањето");
    }
    @Test(priority = 140)
    private void testForVerifyUserCanGivePrice2() {
        Assert.assertEquals(SelenimuSetup.SelectRequest2(), "Понуди за барањето");
    }
    @Test(priority = 150)
    public void testForVerifyUserCanSearchTransport3() {
        Assert.assertEquals(SelenimuSetup.SearchRequest3(), "Наслов на барањето");
    }
    @Test(priority = 160)
    private void testForVerifyUserCanGivePrice3() {
        Assert.assertEquals(SelenimuSetup.SelectRequest3(), "Понуди за барањето");
    }
    @Test(priority = 170)
    public void testForVerifyUserIsLoggedOut1() {
        Assert.assertEquals(SelenimuSetup.logout(), "http://18.156.17.83:9095/");
    }
    @Test(priority = 180)
    public void testForVerifyUserLoggedInAsLookingForTransporter1() {
        Assert.assertEquals(SelenimuSetup.logMeIn(), "");
    }
    @Test(priority = 190)
    public void testForVerifyUserCanDenyOffer() {
        Assert.assertEquals(SelenimuSetup.DenyOffer(), "ИСТЕЧЕНО");
    }
    @Test(priority = 200)
    public void testForVerifyUserCanAcceptOffer() {
        Assert.assertEquals(SelenimuSetup.AcceptOffer(), "ПРИФАТЕНИ ПОНУДИ");
    }
    @Test(priority = 205)
    public void testForVerifyUserCanAcceptOffer2() {
        Assert.assertEquals(SelenimuSetup.AcceptOffer2(), "ПРИФАТЕНИ ПОНУДИ");
    }
    @Test(priority = 210)
    public void testForVerifyUserIsLoggedOut2() {
        Assert.assertEquals(SelenimuSetup.logout(), "http://18.156.17.83:9095/");
    }
    @Test(priority = 220)
    public void testForVerifyUserCanSendMessageInContact() {
        Assert.assertEquals(SelenimuSetup.contact(), "");
    }
    @AfterClass
    public void afterClass() {
        SelenimuSetup.end();
    }
}
